<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?=$page_title ?> </title>
</head>

<style>
    a
    {
color:black;
}
</style>


<body>
<header></header>

<footer >
<?=$page_title ?>
<div id="foot1" style="background-color:#DBB495 ; height:200px">
<img src="images/whatsappicon.webp"  height="100px" >
<img src="images/fbicons.png"  height="100px" >

<nav  style="color:black">
<a href="nkkapoor30@gmail.com" >nkkapoor30@gmail.com,(+438-7285-483)</a> <br>
<a href="kaurparandeep777@gmail.com">kaurparandeep777@gmail.com</a> <br>
</nav>


</div>


</footer>